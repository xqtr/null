   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- ´
   |  _                                                                      |
   ; |                    __   __                                            ;
   :     .-----. .--.--. |  | |  |                                           :
   .     |     | |  |  | |  | |  |                                           .
   ;     |__|__| |_____| |__| |__|  magazine   :: july 2019 :: issue x006    ;
   |                                                                         |
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- '
          _              _   
     __ _| |__  ___ _  _| |_ 
    / _` | '_ \/ _ \ || |  _|
    \__,_|_.__/\___/\_,_|\__| ...

   from now on, null will be published as a DOS executable like the old emags
   of the scene. its done so, because of the "old theme" and also because now
   days, displaying accurate ansi graphics in a linux/windows terminal, becomes
   harder and harder. so by using a dos emulator, you can view 100% accurate
   ansis and also view/read the mag in all sort of devices. wherever dosbox
   runs, you can also extract and read null.
   
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- '   
     _  _ ___ ___ 
    | || (_-</ -_)
     \_,_/__/\___| ...
   
   to read null mag. you use a dos emulator like dosbox. install dosbox in 
   your device (tablet, pc, smartphone) extract the archive and execute the
   file null.exe
   
   null has music! if you don't here it, use the -c switch to configure the
   soundcard. in dosbox type:
                                null -c
   
   type: "null -h" to see other switches as well.
   
   + --- --  -   .     -        ---    ---    ---        -     .    - -- --- '
        _                 _              _ 
     __| |_____ __ ___ _ | |___  __ _ __| |
    / _` / _ \ V  V / ' \| / _ \/ _` / _` |
    \__,_\___/\_/\_/|_||_|_\___/\__,_\__,_|
   
   ok... how are you reading this... you know where to get it all ready :p
   other ways to get it, except the one you used are:
   
   :: github    - https://github.com/xqtr/null
   :: fsxnet    - all fsxnet affiliate boards
   :: zeronet   - all zeronet affiliate boards
   :: bbs       - Another Droid BBS (HQ) / andr01d.zapto.org
                  Agency BBS             / agency.bbs.nz / fsxnet HQ
                  Distortion BBS         / d1st.org / ZeroNet HQ
   
   and everywhere else that is free and easy, for bbs users to access like:
   
   :: scene.org - https://files.scene.org/browse/mags/null/
   :: 16colo.rs website
   