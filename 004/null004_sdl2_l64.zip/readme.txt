
                                      ggg       ggg      
                  $$$eea,.  .o,   ,.  $$$       $$$      
                  $$$``$$$% $$$   $$$ %$$       %$$      
                  $$$---$$$ $$$---$$$ $$$------ $$$------
                  $$$ � $$$ $$$ � $$$ $$$ ��... $$$ ��...
                  $$$---$$$ $$$---$$$ $$$---.oo $$$---.oo
                  $$$   $$$ ^$$aaaS$' ^$$a.a$$' ^$$a.a$$'
                              m a g a z i n e 

                     n e w s � a r t i c l e s � a r t
                     t u t o r s � m o d � m u s i c �
                     � a n s i � v e r s i o n � l 3 2
                     r p i � v e r s i o n � a s c i i
                     s u d o � d o w n l o a d � n o w
                     
::about::
this is a test build for null magazine, for graphical enviroments, using the
sdl2 libraries. nowdays terminals don't support the cp437 codepage and ansi
graphics are displayed distorted in some cases. so i build an engine to 
properly display ansi graphics in gui enviroment, with out the need to making
customizations to terminal programs, to find the right one.

ansi graphics, out of the box... yeah... !!!!                     

::e x e c u t e::
instructions for running a binary file? :? what we've become... anyway... run
it in a linux terminal like this:

                              ./null004l32
                              ./null004rpi
                              
the only exception is that this version is builded for a gui enviroment like
x11, so it wont execute from the terminal.                              

:: i m p o r t a n t::
in this version the sdl2_mixer lib is used. you have to install sdl2 and sdl2
mixer libraries to be able to run this program. at the terminal type this:
  sudo apt-get install libsdl2-mixer-2.0-0 libsdl2-image-2.0-0 libsdl2-2.0-0

                              
the executable supports the following switches:

  --help        : a help screen... no shit... 
  --silent      : this will bypass the whole sound/music system, in case
                  you are getting a "Init Failed" message and/or crash.
                  
::c o n f i g::
inside the package you found some sound files and images. the images are used
for the font to be displayed. there are several of them to test and pick the 
one that suits you. also you can alter them, specially the sound files.

the font file being used is the 80x25.png. if you rename a file like this, it 
will be used for the font. the format of this file is a simple png, containing
a grid 16x16 of the ascii cp437 codepage/characters. the width and height can
be anything you want, but it has to be fixed for all chars. see the included
files to understand it better.

if you don't want to hear the sounds, just remove the files or rename them to
something different.                  

::b u g s::
there is a known bug, while resizing the window. it doesn't happen all the time
but it happens often. i am looking into that, but for now, don't resize the 
window too much.. :)

          you can make the window full screen with alt+enter.


::d o w n l o a d::
you can download or view the magazine from:

                 another droid bbs / andr01d.zapto.org:9999 
                        
                                  or
                                  
                        http://github.com/xqtr/null
                        
                                  or
                
                    http://anotherdroidbbs.wordpress.com/
                    

...or affiliate networks (fsxnet, araknet, dorenet and more).

::c o n t a c t::
send comments, art, articles, angry messages at xqtr@gmx.com. i will ignore 
everything except art and articles :p all complaints will be under great 
consideration and disgarded.

::t e a m::
.. xqtr
.. smooth
.. wanna join? send a msg and you are in... there are plenty of free positions


                                        ggg        ggg      
                  $$$eea,.    ,,   ,.   $$$        $$$      
                  $$$``$$$%  $$$   $$$  %$$        %$$      
                  $$$- -$$$  $$$---$$$  $$$------  $$$------
                  $$$ � $$$  $$$ � $$$  $$$ ��...  $$$ ��...
                  $$$---$$$  $$$---$$$  $$$---.oo  $$$---.oo
                  $$$   $$$  ^$$aaaS$'  ^$$a.a$$'  ^$$a.a$$'

        ggg               ,  ggg    .o                                       
   ,,eee$$$  aaa   aaa,,,a$  $$$_,o$$P  $$$ggggggee,.     ,,aaa$$$   ,,aaa$$$
  $$$`` $$%  $$$  $$$`` $$$  %$$`4eP'   $$$``$$$$``$$$%  $$$`` $$$  $$$`` $$$
  $$$---$$$  ggg  $$$---$$$  $$$--`$$o  $$$ - $$$ - $$$  $$$---$$$  $$$---$$$
  $$$ � $$$  $$$  $$$aa�aaa  $$$ � $$$  $$$ � $$$ � $$$  $$$ � $$$  $$$ � $$$
  $$$---$$$  $$$  ggg---$$$  $$$---$$$  $$$ - $$$ - $$$  $$$---$$$  4$$$$$$$$
  `$$a.a$$$  $$'  ^$$aaaS$$  $$$   $$$  $$$   $$$   $$$  ^$$aaaS$$    .. .S$P
                                                                    .;"`o$$P'
