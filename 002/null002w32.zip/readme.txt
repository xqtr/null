
                                      ggg       ggg      
                  $$$eea,.  .o,   ,.  $$$       $$$      
                  $$$``$$$% $$$   $$$ %$$       %$$      
                  $$$---$$$ $$$---$$$ $$$------ $$$------
                  $$$ � $$$ $$$ � $$$ $$$ ��... $$$ ��...
                  $$$---$$$ $$$---$$$ $$$---.oo $$$---.oo
                  $$$   $$$ ^$$aaaS$' ^$$a.a$$' ^$$a.a$$'
                   m a g a z i n e ~ i s s u e   x 0 0 1

                     n e w s � a r t i c l e s � a r t
                     t u t o r s � m o d � m u s i c �
                     � a n s i � v e r s i o n � l 3 2
                     r p i � v e r s i o n � a s c i i
                     s u d o � d o w n l o a d � n o w

::e x e c u t e::
instructions for running a binary file? :? what we've become... anyway... run
it in a linux terminal like this:

                              ./null001l32
                              ./null001rpi
                              
the executable supports the following switches:

  --help        : a help screen... no shit... 
  --silent      : this will bypass the whole sound/music system, in case
                  you are getting a "Init Failed" message and/or crash.
  --ascii       : it will display all menus in ascii format, for terminals
                  that do not support ansi graphics. you will not be able 
                  to navigate to the ansi art menu :p
                  
::m u s i c / s o u n d   p r o b l e m s::
null uses the bassmod library for playing mod files. because its old it
needs a /dev/dsp device to play the music. in newer systems this is not
present, so you will get no sound or even the program will crash. you have
two options. the first is to execute the program with the --silent switch or
install a package to your system to create/emulate a /dev/dsp device. in 
a debian system like ubuntu, give this:

                      sudo apt-get install osspd-alsa
                      
and reboot your system. to check, give:
        
                      ls /dev/dsp*
                      
and if you see the dsp device, then its ok. run the diskmag as normal and
hear the devine music that has :)


::d o w n l o a d::
you can download or view the magazine from:

                 another droid bbs / andr01d.zapto.org:9999 
                        
                                  or
                                  
                        http://github.com/xqtr/null
                        
                                  or
                
                    http://anotherdroidbbs.wordpress.com/
                    

...or affiliate networks (fsxnet, araknet, dorenet and more).

::c o n t a c t::
send comments, art, articles, angry messages at xqtr@gmx.com. i will ignore 
everything except art and articles :p all complaints will be under great 
consideration and disgarded.

::t e a m::
.. xqtr
.. wanna join? send a msg and you are in... there are plenty of free positions


                                        ggg        ggg      
                  $$$eea,.    ,,   ,.   $$$        $$$      
                  $$$``$$$%  $$$   $$$  %$$        %$$      
                  $$$- -$$$  $$$---$$$  $$$------  $$$------
                  $$$ � $$$  $$$ � $$$  $$$ ��...  $$$ ��...
                  $$$---$$$  $$$---$$$  $$$---.oo  $$$---.oo
                  $$$   $$$  ^$$aaaS$'  ^$$a.a$$'  ^$$a.a$$'

        ggg               ,  ggg    .o                                       
   ,,eee$$$  aaa   aaa,,,a$  $$$_,o$$P  $$$ggggggee,.     ,,aaa$$$   ,,aaa$$$
  $$$`` $$%  $$$  $$$`` $$$  %$$`4eP'   $$$``$$$$``$$$%  $$$`` $$$  $$$`` $$$
  $$$---$$$  ggg  $$$---$$$  $$$--`$$o  $$$ - $$$ - $$$  $$$---$$$  $$$---$$$
  $$$ � $$$  $$$  $$$aa�aaa  $$$ � $$$  $$$ � $$$ � $$$  $$$ � $$$  $$$ � $$$
  $$$---$$$  $$$  ggg---$$$  $$$---$$$  $$$ - $$$ - $$$  $$$---$$$  4$$$$$$$$
  `$$a.a$$$  $$'  ^$$aaaS$$  $$$   $$$  $$$   $$$   $$$  ^$$aaaS$$    .. .S$P
                                                                    .;"`o$$P'
